//
//	class Playground( )
//

	
var SC = 5;

class Playground extends ScormPlayground
{
	static POINTS_SPEED = 2000;
	static FILL_SPEED = 0.4;
	static DRAIN_SPEED = 0.6;

	static PLATE_HIT_SPEED = 100;
	static PLATE_FALL_SPEED = 900;
	
	constructor( )
	{
		super( );
		
		this.resize( );

		this.tank = new Tank;
		this.light.intensity = 3;

		this.translate( [
			{id: 'txt-caption',
				en: 'Ink tank',
				bg: 'Мастилен резервоар',
				jp: 'インクタンク'},
		] );
		

		// create possible variations of inks
		const STEPS = [60,30,20,15,12,10,6,5,4,3];
		const MAX = STEPS[0];
		
		var hashTable = [];
		
		this.inkVariations = [];
		this.inkCounts = [];
		
		for( var step of STEPS )
		{
			var count = MAX/step;
			
			for( var cyan = 0; cyan<=count; cyan++ ) 
			for( var magenta = 0; magenta<=count-cyan; magenta++ )
			{
				var yellow = count-cyan-magenta;
				
				var hash = `${cyan*step},${magenta*step},${yellow*step}`;
				
				if( hashTable.indexOf(hash)==-1 )
				{
					console.log(this.inkVariations.length, '->', hash)
					hashTable.push( hash );
					this.inkVariations.push( hash.split(',') );
				}
			}			
			this.inkCounts.push( this.inkVariations.length );
		}
		
		
		var cols=[];
		var i=0;
		for(var c=0; c<7; c++)
		for(var m=0; m<7; m++)
		for(var y=0; y<7; y++)
		{
			if( (c%2)+(m%2)+(y%2) == 0 ) continue;
			if( (c%3)+(m%3)+(y%3) == 0 ) continue;
			if( (c%5)+(m%5)+(y%5) == 0 ) continue;
			if( (c%7)+(m%7)+(y%7) == 0 ) continue;
			i++
			cols.push( [Math.max(c,m,y)+Math.sign(c)+Math.sign(m)+Math.sign(y),c,m,y] );
		}
		cols=cols.sort( (a,b)=> a[0]-b[0] );
		console.table(cols)
		/*
		2	2-0 	= 3
		3	5-3		= 3
		4	12-6 	= 6
		5	30-13	= 18
		6	60-31	= 30
		7	114-61	= 54
		8	186-115	= 72
		9	252-187 = 66
		*/
		
	} // Playground.constructor

	

	// starts a new game by selecting new color hues
	newGame( )
	{
		this.clickSound?.play();
		
		super.newGame( );

		this.tank.water.clearWater( );
console.log('>>>',this.inkCounts)
		// invent new color
		// inkVariations[] contains many colours, in groups with increasing difficulty
		// inkCounts[] marks the end of each group, pick a random color from the
		// beginning of inkVariations[] till the end of a group dependent on difficulty
		var countIdx = Math.min( Math.round(this.difficulty/10), this.inkCounts.length-1 ),
			cmy = random( this.inkVariations.slice(0,this.inkCounts[ countIdx ]) ),
			max = Math.max( cmy[0], cmy[1], cmy[2] );

		
		new TWEEN.Tween( this.tank.water.plate )
			.to( {y:this.tank.water.plate.y+2/SC}, Playground.PLATE_HIT_SPEED )
			.easing( TWEEN.Easing.Quartic.Out )
			.chain( 
				new TWEEN.Tween( this.tank.water.plate )
					.to( {y:this.tank.water.plate.y}, Playground.PLATE_FALL_SPEED )
					.easing( TWEEN.Easing.Bounce.Out )
			).start( );
		
		var colorA = rgb( ...playground.tank.water.plateColor.color );
		var colorB = rgb(
							255 - 255*cmy[0]/max,
							255 - 255*cmy[1]/max,
							255 - 255*cmy[2]/max
						);
		var target = playground.tank.water.plateColor;
		new TWEEN.Tween( colorA )
			.to( colorB, Playground.PLATE_FALL_SPEED )
			.onUpdate( color => target.color = color )
			.delay( Playground.PLATE_HIT_SPEED )
			.start( );
		
	} // Playground.newGame
	
	
	
	// returns the score of the current game
	evaluateGame( )
	{
		var points = this.configRange( 30, 100 );
		var granularity  = this.configRange( 3, 10 );
		
		var water = this.tank.water,
			max = Math.max( water.cyan, water.magenta, water.yellow );
		
		var userC = Math.round(granularity*water.cyan/max),
			userM = Math.round(granularity*water.magenta/max),
			userY = Math.round(granularity*water.yellow/max);
		
		var goalC = Math.round(granularity*(1-water.plateColor.color[0])),
			goalM = Math.round(granularity*(1-water.plateColor.color[1])),
			goalY = Math.round(granularity*(1-water.plateColor.color[2]));
		
		var error = Math.hypot( userC-goalC, userM-goalM, userY-goalY );

		var score = THREE.MathUtils.mapLinear( error, 1, granularity, 1, 0 );
			score = THREE.MathUtils.clamp( score, 0, 1 );
		
		return score * points;

	} // Playground.evaluateGame
	
	
	
	// ends the current game - evaluate results, update data
	endGame( )
	{
		this.clackSound.play();
		
		super.endGame( );
		
		this.tank.water.drainAll( );
		
	} // Playground.endGame
	


	// update the viewpoint to set the image size depending
	// on orientation of mobile devices
	resize( )
	{
		// ...
	} // Playground.resize
	


	// load all sounds
	loadSounds( )
	{
		this.clickSound = new PlaygroundAudio( 'sounds/click.mp3', 0.1 );
		this.clackSound = new PlaygroundAudio( 'sounds/clack.mp3', 0.03 );
		this.boomSound = new PlaygroundAudio( 'sounds/boom.mp3', 0.2 );
		this.bubblesSound = new PlaygroundAudio( 'sounds/bubbles.mp3', 0, 1,  true );
		this.backgroundMelody = new PlaygroundAudio( 'sounds/background.mp3', 0.2, 1, true, false );
		
		this.soundEffects.push( this.clickSound, this.clackSound, this.boomSound, this.bubblesSound );
		this.soundMelody.push( this.backgroundMelody );
	} // Playground.loadSounds
	
	
	
	// floating plate
	update( t, dT )
	{
		this.light.position.copy( suica.camera.position );
		
		if( playground.gameStarted )
		{
			var aperture = Math.max( this.tank.cyanPipe.aperture, this.tank.magentaPipe.aperture, this.tank.yellowPipe.aperture );
			if( aperture > 0 )
			{
				if( this.bubblesSound )
				{
					this.bubblesSound.setVolume( 0.3*aperture );
				}
				
				this.tank.water.addInk( 'cyan', Math.pow(this.tank.cyanPipe.aperture,2)*dT*Playground.FILL_SPEED );
				this.tank.water.addInk( 'magenta', Math.pow(this.tank.magentaPipe.aperture,2)*dT*Playground.FILL_SPEED );
				this.tank.water.addInk( 'yellow', Math.pow(this.tank.yellowPipe.aperture,2)*dT*Playground.FILL_SPEED );
			}
		}
		else
			this.tank.water.colorize( t );

		this.tank.water.waves( t );
			
	}
} // class Playground
