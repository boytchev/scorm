//
//	class Water( )
//

	

class Water extends Group
{
	constructor( )
	{
		super( suica );

		this._level = 0;
		
		this.water = cube( [0,0,0], [Tank.WIDTH-2*Tank.FRAME_WIDTH/3,0] );
		this.water.threejs.material = new THREE.MeshBasicMaterial({
			color: 'cyan',
			polygonOffset: true,
			polygonOffsetUnits: 1,
			polygonOffsetFactor: 1,
			transparent: true,
			opacity: 0.5,
		});
		this.water.threejs.renderOrder = -1;
		
		this.waterBorder = square( [0,0,0], Tank.WIDTH-2*Tank.FRAME_WIDTH/3, 'black' );
			its.wireframe = true;
			its.spinV = 90;
			its.threejs.material.transparent = true;
			its.threejs.material.opacity = 0.3;
			its.threejs.renderOrder = -1;

		this.plate = group(
			cube( [0,Tank.PLATE_HEIGHT/2,0], [Tank.PLATE_SIZE, Tank.PLATE_HEIGHT] ),
			cube( [0,Tank.PLATE_HEIGHT/2,0], [Tank.PLATE_SIZE, Tank.PLATE_HEIGHT], 'black' ).style({ wireframe:true }),
			square( [0,Tank.PLATE_HEIGHT,0], Tank.PLATE_SIZE ).style({ spinV:-90 }),
		);
		
		// this.targetColorPlate = new THREE.Mesh(
			// new THREE.PlaneBufferGeometry( PLATE_SUBSIZE, PLATE_SUBSIZE ),
			// new THREE.MeshBasicMaterial({
				// polygonOffset: true,
				// polygonOffsetFactor: -2,
				// polygonOffsetUnits: -2
			// })
		// );
		// this.targetColorPlate.rotation.x = -Math.PI/2;
		// this.targetColorPlate.position.y = PLATE_HEIGHT/2;
		// this.targetColorBox.add(this.targetColorPlate);
		// this.image.add( this.targetColorBox );

		this.add( this.water, this.waterBorder, this.plate );
		
	} // Water.constructor
	
	
	
	get level( )
	{
		return this._level;
	}
	
	set level( level )
	{
		this._level = level;
		
		var height = level * Tank.WATER_HEIGHT;
		
		this.water.y = height/2 + Tank.BASE_HEIGHT;
		this.water.height = height;
		this.water.threejs.material.opacity = level;
		
		this.waterBorder.y = height + Tank.BASE_HEIGHT;

		this.plate.y = height + Tank.BASE_HEIGHT;
		
	} // Water.level
	
} // class Water

