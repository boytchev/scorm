//
//	class Playground( )
//

	

class Playground extends ScormPlayground
{
	static POINTER_MOVEMENT = 5;
	static POINTER_USED = false;
	static ENABLE_USER = false;
	
	constructor( )
	{
		super( );
		
		this.pointerMovement = 0;
		
		
		this.resize( );

		this.translate( [
			{id: 'txt-caption',
				en: 'Platonic walk',
				bg: 'Платонична разходка',
				jp: 'プラトニックな散歩------'},
		] );
		
		// the Platonic solids
		this.solid = null;
		this.solids = [];
		for( var i=0; i<5; i++ )
			this.solids.push( new Platonic( i ) );

		// the 3D model (Claire)
		this.model = new THREEJSModel();
		this.modelShell = prism( 6, [0,-THREEJSModel.HEIGHT,0], [2*THREEJSModel.SIZE,THREEJSModel.HEIGHT+9], 'crimson' );
			its.visible = false;
			its.addEventListener( 'click', this.onClickModel )

		this.addLightsAndShadows( );

		this.createGlythRing( );

	} // Playground.constructor


	
	// create the ring of glyphStroke
	createGlythRing( )
	{
		const RING_SIZE = 25,
			  RING_HEIGHT = 2;

		this.route = [];
		this.routeRing = tube( [0,0,0],
				[	[0,RING_HEIGHT,0,0.98*RING_SIZE],
					[0,RING_HEIGHT/2,0,RING_SIZE],
					[0,0,0,1.01*RING_SIZE],
					[0,-RING_HEIGHT/2,0,RING_SIZE],
					[0,-RING_HEIGHT,0,0.98*RING_SIZE]
				], 1, [10,120], 0, 'white' );
			its.threejs.material = new THREE.MeshPhysicalMaterial( {
				transparent: true,
				opacity: 2,
				metalness: 0,
				roughness: 0.5,
				side: THREE.DoubleSide,
				sheenColor: 'navy',
				sheen: 2,
				sheenRoughness: 0.25,
			} );
			this.routeRing.threejs.renderOrder = -15;

		this.ringImage = drawing( 1024, 128 );
		this.ringAlpha = drawing( 1024, 128 );
		this.setGlyphTexture( );
	} // Playground.createGlythRing
	
	
	
	// generate glyph shape fo the current route
	glyphStroke( img, seed )
	{
		const START_X = 20;
		const START_Y = 64; // half of ringImage height

		const LINE_STEP = 16;
		const CIRCLE_RADIUS = 16;
		const CIRCLE_MIN_RADIUS = 5;

		
		// stabilize randomness for left- and right- arcs
		// for main image to be the same as for the alpha map
		THREE.MathUtils.seededRandom( seed );
		
		// starting point
		var x = START_X,
			y = START_Y;
		
		// starting node - a small dot
		img.moveTo( x, y+CIRCLE_MIN_RADIUS );
		img.arc( x, y, CIRCLE_MIN_RADIUS );
		img.moveTo( x, y );
		x += LINE_STEP;
		img.lineTo( x, y );

		// generate all glyphs
		for( var i=0; i<this.route.length; i++ )
		{
			var count = Math.abs(this.route[i]), // numer of arcs
				sign = Math.sign(this.route[i]); // up(1) or down(-1)
			
			var prevX = x - CIRCLE_RADIUS - 0.5*LINE_STEP,
				nextX = x + count*LINE_STEP + CIRCLE_RADIUS + 0.5*LINE_STEP;
				
			// draw up/down arcs
			var treshold;

			// arcs below treshold are curved to the left, arcs above - to the right
			if( count < 4 )
				treshold = THREE.MathUtils.seededRandom() * (count+1) - 1;
			else
				treshold = THREE.MathUtils.seededRandom() * (count-1) + 1;

			// draw arcs
			for( var j=0; j<count; j++ )
			{
				img.moveTo( x + (j+0.5)*LINE_STEP, y );
				
				if( j < treshold )
				{
					// curve left
					if( sign > 0 )
						img.arc( prevX, y, x + (j+0.5)*LINE_STEP - prevX, 90, 45, false ); // up
					else
						img.arc( prevX, y, x + (j+0.5)*LINE_STEP - prevX, 90, 135, true ); // down
				}
				else
				{
					// curve right
					if( sign > 0 )
						img.arc( nextX, y, nextX - (x+(j+0.5)*LINE_STEP), 270, 315, true ); // up
					else
						img.arc( nextX, y, nextX - (x+(j+0.5)*LINE_STEP), 270, 225, false ); // down
				}
			}
			
			// draw horizontal line
			img.moveTo( x, y );
			x += (count) * LINE_STEP;
			img.lineTo( x, y );
			
			// if not the last one, add a big circle
			if( i < this.route.length-1 )
			{
				img.moveTo( x, y );
				x += 0.5 * LINE_STEP;
				img.lineTo( x, y );
				
				img.moveTo( x+CIRCLE_RADIUS, y+CIRCLE_RADIUS );
				img.arc( x+CIRCLE_RADIUS, y, CIRCLE_RADIUS );

				x += 2*CIRCLE_RADIUS;
				
				img.moveTo( x, y );
				x += 0.5 * LINE_STEP;
				img.lineTo( x, y );
			}
			
		}

		// ending node
		img.moveTo( x, y );
		x += LINE_STEP;
		img.lineTo( x, y );
		img.moveTo( x, y+CIRCLE_MIN_RADIUS );
		img.arc( x, y, CIRCLE_MIN_RADIUS );

		// calculate rotation to center the glyphStroke
		// 		x - START_X 	glyph width in texels
		//		/2				half the width
		//		/1024			fraction from the whole texture
		//		/5				there are 5 textures in a ringAlpha
		//		*360			a ring is 360 degrees
		this.ringSpin = - (x - START_X + 40)/2/1024/5*360;
	} // Playground.glyphStroke


	// set ring texture
	setGlyphTexture( )
	{
		var material = this.routeRing.threejs.material;
		
		var seed = Math.floor( random(1,100000) );

		// draw the glyph image (used as map texture)
		this.ringImage.clear( 'Crimson' );
		this.glyphStroke( this.ringImage, seed );
		this.ringImage.stroke( 'Black', 14 );
		this.ringImage.stroke( 'Yellow', 10 );
		
		if( material.map ) material.map.dispose( );
		material.map = new THREE.CanvasTexture( this.ringImage.canvas );
		material.map.repeat.set( 5, 1 ); 
		material.map.rotation = Math.PI/2; 
		material.map.offset.set( 0, 1 );
		material.map.wrapS = THREE.RepeatWrapping;
		material.map.wrapT = THREE.RepeatWrapping;			
		
		// draw the glyph alpha map
		this.ringAlpha.clear( '#202020' );
		this.ringAlpha.context.shadowBlur = 5;
		this.ringAlpha.context.shadowColor = "white";
		this.glyphStroke( this.ringAlpha, seed );
		this.ringAlpha.stroke( 'White', 12 );
		this.ringAlpha.moveTo( 0, 0 );
		this.ringAlpha.lineTo( 1024, 0 );
		this.ringAlpha.moveTo( 0, 128 );
		this.ringAlpha.lineTo( 1024, 128 );
		this.ringAlpha.stroke( 'dimgray', 2 );
		
		if( material.alphaMap ) material.alphaMap.dispose( );
		material.alphaMap = new THREE.CanvasTexture( this.ringAlpha.canvas );
		material.alphaMap.repeat.set( 5, 1 ); 
		material.alphaMap.rotation = Math.PI/2; 
		material.alphaMap.offset.set( 0, 1 );
		material.alphaMap.wrapS = THREE.RepeatWrapping;
		material.alphaMap.wrapT = THREE.RepeatWrapping;			

	} // Playground.setGlyphTexture
	

		
	// clicking on the model while the game is not started
	// starts a new game
	onClickModel( )
	{
		if( playground.pointerMovement > Playground.POINTER_MOVEMENT )
			return;

		if( !playground.gameStarted )
			if( Playground.ENABLE_USER )
				playground.newGame( );
	} // Playground.onClickModel

	
	
	// starts a new game 
	newGame( )
	{
		super.newGame( );

		this.clickSound.play( );

		this.routeRing.spinH = random( -180, 180 );
		this.routeRing.spinV = random( -180, 180 );
		this.routeRing.spinT = random( -180, 180 );

		// remove model shell (because otherwise it will capture onclick events)
		this.modelShell.y = 1000;
		
		// pick solid index, spot index and route parameters
		this.solidIdx = this.difficulty<30 ? 0 : random( [0,1,2,3,4] );
		this.spotIdx = Math.floor( random(0, this.solids[this.solidIdx].spots.length) );
		
		var	routeLength = this.configRangeInt( 1, 6, 2 ),
			routeMax = this.configRange( 2, 5 );

		// generate descriptor of the route; forward > 0, backward < 0, twin between two numbers
		// [2,-2,3,0] means FFtBBtFFFt
		this.route = [];
		for( var i=0; i<=routeLength; i++ )
			this.route.push( Math.floor(routeMax * random(0,1)**0.5 ) * random([-1,1]) );

		this.setGlyphTexture( );
		
		// show selected solid
		this.solid = this.solids[this.solidIdx];
		this.solid.show( this.spotIdx );

		// move to a random slot
		this.model.moveToSpot( this.spotIdx );
	} // Playground.newGame



	// check whether a game can end
	canEndGame( )
	{
		// it can, if there is a selected plate
		return Plate.selected;
	} // Playground.canEndGame
	
	
	
	// returns the score of the current game
	evaluateGame( )
	{
		var points = this.maxPoints( );
		
		// traverse the route to find the correct ending plate
		var spotIdx = this.spotIdx;
		for( var i=0; i<this.route.length; i++ )
		{
			var count = Math.abs( this.route[i] ),
				dir   = Math.sign( this.route[i] );
				
			if( dir > 0 )
				for( ; count>0; count-- ) spotIdx = this.solid.nextSpot[ spotIdx ];
			else
				for( ; count>0; count-- ) spotIdx = this.solid.prevSpot[ spotIdx ];
			
			if( i<this.route.length-1 )
				spotIdx = this.solid.twinSpot[ spotIdx ];
		}
		
		var plateIdx = this.solid.spotPlate[ spotIdx ];

		// calculate score: 1=match, 0.5=almost match
		
		var score = 0;
		
		if( plateIdx == Plate.selected.index )
		{
			// correctly selected plate
			score = 1;
		}
		else
		if( this.solid.plates.length > 10 )
		{
			// if the number of plates high (dodecahedron or icosahedron)
			// check wether selected and correct plate are neighbours
			// there must be twins from both plates. if neighbours, give 50%
			for( var i=0; i<this.solid.twinSpot.length; i++ )
			{
				if( this.solid.spotPlate[i] == plateIdx &&
					this.solid.spotPlate[this.solid.twinSpot[i]] == Plate.selected.index )
					score = 0.5;
			}
		}
		
		return score * points;

	} // Playground.evaluateGame
	
	
	
	// ends the current game - evaluate results, update data
	endGame( )
	{
		super.endGame( );
		
		this.clackSound.play( );
		
		this.solid.hide( );
		
		this.modelShell.y = -THREEJSModel.HEIGHT;
		
		this.model.moveToCenter( );
		
	} // Playground.endGame
	


	// update the viewpoint to set the image size depending
	// on orientation of mobile devices
	resize( )
	{
		// ...
	} // Playground.resize
	


	// load all sounds
	loadSounds( )
	{
		this.clickSound = new PlaygroundAudio( 'sounds/click.mp3', 0.1, 4 );
		this.clackSound = new PlaygroundAudio( 'sounds/clack.mp3', 0.03 );
		this.backgroundMelody = new PlaygroundAudio( 'sounds/background.mp3', 0.2, 1, true );
		
		this.soundEffects.push( this.clickSound, this.clackSound );
		this.soundMelody.push( this.backgroundMelody );
	} // Playground.loadSounds
	
	
	
	// add support for lights and shadows
	addLightsAndShadows( )
	{
		// allow shadows
		suica0.renderer.shadowMap.enabled = true;
		suica0.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

		var light = new THREE.DirectionalLight( 'white', 0.3 );
			light.position.set( 0, 100, 0 );
			light.target = suica0.scene;
			light.castShadow = true;

			light.shadow.mapSize.width = 512;
			light.shadow.mapSize.height = 512;
			light.shadow.camera.left = -20;
			light.shadow.camera.right = 20;
			light.shadow.camera.bottom = -20;
			light.shadow.camera.top = 20;
			light.shadow.camera.near = 1;
			light.shadow.camera.far = 500;

		suica0.scene.add( light );
		
		this.shadowLight = light;		
	} // Playground.addLightsAndShadows



	// update the playground
	update( t, dT )
	{
		// fix the shadow light to the normal light, which is
		// fixed by Suica to the viewing position
		this.shadowLight.position.x = suica0.light.position.x+15;
		this.shadowLight.position.y = suica0.light.position.y+10;
		this.shadowLight.position.z = suica0.light.position.z+5;
		this.shadowLight.target = suica0.scene;

		// spin the ring to have a glyph centered on the screen
		if( !Playground.POINTER_USED )
		{
			var k = THREE.MathUtils.clamp( 1-5*dT, 0.5, 0.99 );

			this.routeRing.spinH = k*this.routeRing.spinH + (1-k)*(180/Math.PI * orb.getAzimuthalAngle( ));
			this.routeRing.spinV = k*this.routeRing.spinV + (1-k)*(180/Math.PI * orb.getPolarAngle( ) - 90 + 15);
			this.routeRing.spinT = this.ringSpin;
		}
	
		this.model.update( t, dT );
	}
	
} // class Playground
